class Triathlon {

}